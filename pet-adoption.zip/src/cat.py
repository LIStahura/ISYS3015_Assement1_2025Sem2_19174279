from pet import Pet

class Cat(Pet):
    def __init__(self, name, age, breed):
        # TODO: Initialize the dog
        pass

    # TODO: Implement dog-specific methods