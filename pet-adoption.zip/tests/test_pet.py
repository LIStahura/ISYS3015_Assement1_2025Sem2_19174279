import pytest
from src.pet import Pet

def test_pet_initialization():
    # TODO: Write a test to check if a Pet object is initialized correctly
    pass

# TODO: Write at least one more test for the Pet class